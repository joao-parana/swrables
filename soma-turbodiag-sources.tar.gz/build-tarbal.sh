#!/bin/bash

rm  -rf ../turbodiag-python.tar
tar -cf ../turbodiag-python.tar *
ls  -la ../turbodiag-python.tar


